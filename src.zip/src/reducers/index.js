// src/reducers/index.js
import guesses from './guesses'
import word from './word'

export default {
  word,
  guesses
} // empty for now!
