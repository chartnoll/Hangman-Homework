// src/reducers/board.js

const initialState = {
  word: "hello",
  guesses: []
}

export default (state = initialState, { type, payload } = {}) => {
  return state
}
