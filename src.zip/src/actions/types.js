export const NEW_GUESS = 'NEW_GUESS'
